Packet 4 - UI polish and reusable Life Pilot components

Use this packet for Packet 4 only.

Important:
- Work only on the copied commercial Life Pilot build.
- Do not start Packet 5.
- Do not rebuild core behaviour.
- Use the logo and swatch board as visual references only unless explicitly asked to import them.

Tasks:
1. Apply warm sand background, near-white cards, deep slate text and teal primary actions.
2. Use signal orange only for important next actions or attention markers.
3. Create or refine reusable card/button/status styles.
4. Introduce the four-dash motif only as a restrained system marker if safe.
5. Review empty states and labels for non-shaming plain language.

Hard stop:
Stop after UI polish and report changed files, checks run and risks.
