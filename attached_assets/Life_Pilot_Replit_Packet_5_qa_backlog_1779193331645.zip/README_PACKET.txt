Packet 5 - QA, commercial readiness review and next-step backlog

Use this packet for Packet 5 only.

Important:
- Do not start new feature work.
- Do not fix everything automatically.
- Do not build the social-impact layer.

Tasks:
1. Run available tests, lint/build checks or manual smoke checks.
2. Review key screens for broken labels, layout drift and leftover personal-only MYOH references.
3. List commercial-readiness issues without fixing everything automatically.
4. Create a next-step backlog split into small future packets.
5. Confirm original MYOH was not touched.

Hard stop:
Final review report only. Stop and wait for explicit instruction.
