Packet 1 - Inspect copied MYOH build only

Use this packet for Packet 1 only.

Important:
- This is for the copied commercial Life Pilot build, not the original MYOH test build.
- Do not edit files.
- Do not apply branding yet.
- Do not start Packet 2.
- Do not build the social-impact layer.

Tasks:
1. Inspect the copied app structure, routes, navigation and styling.
2. Identify main layout, dashboard and theme files.
3. Find app-name/display-label locations.
4. Flag database/schema/auth-sensitive files that must not be touched.
5. Flag personal/test-specific MYOH references that need review before commercialising.

Hard stop:
Report current routes/tabs, main components, styling files, naming risks, personal/test-specific references and safest first implementation step. Then stop.
