Packet 2 - Brand tokens and safe display naming

Use this packet for Packet 2 only.

Important:
- Work only on the copied commercial Life Pilot build.
- Preserve original MYOH.
- Do not change database names, table names, auth logic or major data structures.
- Do not start Packet 3.
- Do not build the social-impact layer.

Tasks:
1. Add Life Pilot colour tokens/CSS variables where safe.
2. Add Life Pilot font variables or font stacks where safe.
3. Update safe user-facing display names from MYOH to Life Pilot where isolated.
4. Leave code/internal/database names unchanged unless clearly safe.
5. Report any MYOH references intentionally left in place.

Hard stop:
Stop after token/display-name changes and report changed files, checks run and risks.
