Packet 3 - Commercial Life Pilot navigation shell

Use this packet for Packet 3 only.

Important:
- Work only on the copied commercial Life Pilot build.
- Do not start Packet 4.
- Do not rebuild the app.
- Do not add Job Pilot, Gig Pilot or social-impact modules.

Tasks:
1. Map existing MYOH areas to Money Life, Work Life, Home Life and Support Life.
2. Add or relabel navigation only where low risk.
3. Create dashboard bucket cards if the existing dashboard supports it safely.
4. Use Life Pilot copy for attention states and next practical steps.
5. Keep Documents/Evidence and Settings where they already fit.

Hard stop:
Stop after navigation/dashboard shell changes and report.
